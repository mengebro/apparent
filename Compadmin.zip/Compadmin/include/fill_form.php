
<?php

require_once("DB_connection.php");

$msg="";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $comapnyName=$_POST['InputName'];
    $city=$_POST['city'];
    $companyemail=$_POST["companyemail"];

    $InputEmailSecond=$_POST["InputEmailSecond"];
    $InputPhoneNumber=$_POST["InputPhoneNumber"];
    $InputPostalNumber=$_POST["InputPostalNumber"];
    $InputDepartment=$_POST["InputDepartment"];

    $companyDetails=$_POST["companyDetails"];
    $Inputprice=$_POST["Inputprice"];
    $Inputcgpa=$_POST["Inputcgpa"];
    $duration=$_POST["duration"];
    $Inputweb=$_POST["Inputweb"];
    $agreement=$_POST["agreement"];
    $image=$_POST["image"];



        $query=mysqli_query($conn,  "SELECT * FROM companyinfo WHERE company_name = '$comapnyName' ");
        $numrows=mysqli_num_rows($query);
        if($numrows==0)
        {

            $sql="INSERT INTO companyinfo (company_name,city,email,phone_number,postal_number,department,descrption,price_status,min_CGpA,Duration,web_link,agrement_pdf,image)
      VALUES ('$comapnyName','$city','$companyemail','$InputPhoneNumber','$InputPostalNumber','$InputDepartment','$companyDetails','$Inputprice','$Inputcgpa','$duration','$Inputweb','$agreement','$image')";

            $result=mysqli_query($conn,$sql);


            if($result){

                echo " <p style='color: #008000;'>Sucecessfully Added</p>";
            } else{
                echo " <p style='color: red;'>Failed.</p>";
            }
        }else
        {
            echo " <p style='color: red;'>This post is already registered.</p>";
        }

}
?>