<?php

require_once("DB_connection.php");
$query = "SELECT * FROM student ORDER BY std_id ASC";
$result = mysqli_query($conn,$query);
if(mysqli_num_rows($result)>0)
{
if( $row=mysqli_fetch_array($result))
{



$id= $row["std_id"];
 
   

$to= 'mergawolde@gmail.com';
$subject = 'the subject';
$message = 'hello';
$headers = array(
    'From' => 'ethiomengistu@gmail.com',
    'Reply-To' => 'ethiomengistu@gmail.com',
    'X-Mailer' => 'PHP/' . phpversion()
);

$retval=mail($to, $subject, $message, $headers);


         
         if( $retval == true ) {
            echo "Message sent successfully...";
         }else {
            echo "Message could not be sent...";
}
}
}
?> 